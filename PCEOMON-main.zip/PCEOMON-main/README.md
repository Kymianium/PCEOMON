# PCEOMON
Proyecto PCEOMON, GOTY del 2034.


Este proyecto ha sido creado por alumnos de la universidad de Murcia. Es nuestra manera de hacer algo permanente de nuestro paso por la UMU. Nuestra voluntad es que el proyecto se mantenga vivo por futuras generaciones del PCEO. Proyecto realizado en GODOT.
